function [R,fluxes,rad,thermal,profiles,soil,iter] = ...
    SCOPEmodel(k,V,vi,vmax,soil,leafbio,canopy,meteo,angles,atmo,spectral,...
    optipar,directional,xyt,iter,options,Output_dir)
% % HELP: SCOPEmodel is a function runing the SCOPE model, this is almost
% % the same code that can be found in the cell "14. Run the model" of the
% % original SCOPE model v1.73, converted into a function.
% % An additional option (options.store) is used to prevent storing results 
% % during inversion, but to be able to do it once the parametrs have been 
% % estimated. The function also provides the hemispherical-directional
% % reflectance factor in the observation as an output.
% % 
% % Input arguments:
% %     k: integer, index of the time series of inputs to simulate
% %     x: vector, model parameters to be evaluated
% %     V: structure, containing model inputs and inversion constraints
% %     vi: vector, position of the data corresponding to a given time step
% % in the V structure
% %     vmax: integer, maximum length of the time series
% %     soil: structure, contains SCOPE model soil parameters
% %     leafbio: structure, contains SCOPE model leaf biophysical and 
% % functional parameters
% %     canopiy: structure, contains SCOPE model canopy structural
% % parameters
% %     meteo: structure, contains SCOPE model meteorological variables
% %     angles: structure, contains SCOPE model sun-view geometry variables
% %     atmo: structure, contains SCOPE model atmospheric transfer 
% % functions
% %     spectral: structure, contains SCOPE moel spectral features.
% %     optipar: structure, contains SCOPE model soil and vegetation 
% % optical constants
% %     directional: structure, contains SCOPE model multi-angular sun-view
% % geometry if meant to be computed
% %     xyt: structure, contains SCOPE spatial and temporal coordinates
% %     iter: structure, ,contains metaparameters for the energy balance
% %     observations: structure, contains the observational variables used
% % to constrain the inversion
% %     options: structure, contains SCOPE model options as well as 
% % additional options for the inversion
% %     Output_dir: string, contains the path where outputs will be stored
% % 
% % Output arguments: 
% %     R: vector, hemispherical-directional reflectance factor in the
% % direction of observation
% %     fluxes: structure, contains SCOPE model carbon and energy predicted 
% % fluxes
% %     rad: structure, contains SCOPE model predicted spectro-radiometric
% % variables
% %     thermal: structure, contains SCOPE model predicted thermal related
% % variables
% %     profiles: structure, contains SCOPE model predicted vertical
% % profiles of some variables
% %     soil: structure, contains SCOPE model soil parameters and some
% % predicted variables
% %     iter: structure, ,contains metaparameters for the energy balance
% % and returns information on the energy balance closure
% % 
% % Author: Javier Pacheco-Labrador, MPI-BGC, Jena, Germany. 2019-Sep-16
% % 
% % HISTORY:
% %     Created: Javier Pacheco-Labrador. 2019-Sep-16
% % 
 
 
%% Get some variables that need to be defined / preallocated
nwlP = length(spectral.wlP);
nwlT = length(spectral.wlT);
IwlP = spectral.IwlP;
IwlT = spectral.IwlT;
[rad,thermal,fluxes] = io.initialize_output_structures(spectral);
[rho,tau,rs] = deal(zeros(nwlP + nwlT,1));


%% Run model
    if options.simulation ~=1
% %         fprintf('simulation %i ', k );
% %         fprintf('of %i \n', telmax);
    else
        calculate = 0;
%         if k>=I_tmin && k<=I_tmax
            quality_is_ok   = ~isnan(meteo.p*meteo.Ta*meteo.ea*meteo.u.*meteo.Rin.*meteo.Rli);
% %             fprintf('time = %4.2f \n', xyt.t(k));
            if quality_is_ok
                calculate = 1;
            end
%         end
    end
    
    if calculate        
        iter.counter = 0;
        
%         LIDF_file            = char(F(22).FileName);
%         if  ~isempty(LIDF_file)
%             canopy.lidf     = dlmread([path_input,'leafangles/',LIDF_file],'',3,0);
%         else
        canopy.lidf     = equations.leafangles(canopy.LIDFa,canopy.LIDFb);    % This is 'ladgen' in the original SAIL model,
%         end
        
        if options.calc_PSI
            fversion = @fluspect_B_CX;
        else
            fversion = @fluspect_B_CX_PSI_PSII_combined;
        end
        leafbio.V2Z = 0;
        leafopt  = fversion(spectral,leafbio,optipar);
        leafbio.V2Z = 1;
        leafoptZ = fversion(spectral,leafbio,optipar);
        
        IwlP     = spectral.IwlP;
        IwlT     = spectral.IwlT;
        
        rho(IwlP)  = leafopt.refl;
        tau(IwlP)  = leafopt.tran;
        rlast    = rho(nwlP);
        tlast    = tau(nwlP);
        
        if options.soilspectrum == 0
            rs(IwlP) = rsfile(:,soil.spectrum+1);
        else
            soilemp.SMC   = 25;        % empirical parameter (fixed)
            soilemp.film  = 0.015;     % empirical parameter (fixed)
%             Use these parameters for SMANIE data
%             soilemp.SMC   = 43.29;        % empirical parameter (fixed)
%             soilemp.film  = 0.012;     % empirical parameter (fixed)
            rs(IwlP) = BSM(soil,optipar,soilemp);
        end
        rslast   = rs(nwlP);
        
        switch options.rt_thermal
            case 0
                rho(IwlT) = ones(nwlT,1) * leafbio.rho_thermal;
                tau(IwlT) = ones(nwlT,1) * leafbio.tau_thermal;
                rs(IwlT)  = ones(nwlT,1) * soil.rs_thermal;
            case 1
                rho(IwlT) = ones(nwlT,1) * rlast;
                tau(IwlT) = ones(nwlT,1) * tlast;
                rs(IwlT)  = ones(nwlT,1) * rslast;
        end
        leafopt.refl = rho;     % extended wavelength ranges are stored in structures
        leafopt.tran = tau;
        
        reflZ = leafopt.refl;
        tranZ = leafopt.tran;
        reflZ(1:300) = leafoptZ.refl(1:300);
        tranZ(1:300) = leafoptZ.tran(1:300);
        leafopt.reflZ = reflZ;
        leafopt.tranZ = tranZ;
        
        soil.refl    = rs;
        
        soil.Ts     = meteo.Ta * ones(2,1);       % initial soil surface temperature
        
% %         if length(F(4).FileName)>1 && options.simulation==0
% %             atmfile     = [path_input 'radiationdata/' char(F(4).FileName(k))];
% %             atmo.M      = helpers.aggreg(atmfile,spectral.SCOPEspec);
% %         end
        atmo.Ta     = meteo.Ta;
        
        [rad,gap,profiles]   = RTMo(spectral,atmo,soil,leafopt,canopy,angles,meteo,rad,options);
        
        switch options.calc_ebal
            case 1
                [iter,fluxes,rad,thermal,profiles,soil]                          ...
                    = ebal(iter,options,spectral,rad,gap,                       ...
                    leafopt,angles,meteo,soil,canopy,leafbio,xyt,k,profiles);
                
                if options.calc_fluor
                    if options.calc_vert_profiles
                        [rad,profiles] = RTMf(spectral,rad,soil,leafopt,canopy,gap,angles,profiles);
                    else
                        [rad] = RTMf(spectral,rad,soil,leafopt,canopy,gap,angles,profiles);
                    end
                end
                if options.calc_xanthophyllabs
                    [rad] = RTMz(spectral,rad,soil,leafopt,canopy,gap,angles,profiles);
                end
                
                if options.calc_planck
                    rad         = RTMt_planck(spectral,rad,soil,leafopt,canopy,gap,angles,thermal.Tcu,thermal.Tch,thermal.Ts(2),thermal.Ts(1),1);
                end
                
                if options.calc_directional
                    directional = calc_brdf(options,directional,spectral,angles,rad,atmo,soil,leafopt,canopy,meteo,profiles,thermal);
                end
                
            otherwise
                Fc              = (1-gap.Ps(1:end-1))'/nl;      %           Matrix containing values for Ps of canopy
                fluxes.aPAR     = canopy.LAI*(Fc*rad.Pnh        + equations.meanleaf(canopy,rad.Pnu    , 'angles_and_layers',gap.Ps));% net PAR leaves
                fluxes.aPAR_Cab = canopy.LAI*(Fc*rad.Pnh_Cab    + equations.meanleaf(canopy,rad.Pnu_Cab, 'angles_and_layers',gap.Ps));% net PAR leaves
                [fluxes.aPAR_Wm2,fluxes.aPAR_Cab_eta] = deal(canopy.LAI*(Fc*rad.Rnh_PAR    + equations.meanleaf(canopy,rad.Rnu_PAR, 'angles_and_layers',gap.Ps)));% net PAR leaves
                if options.calc_fluor
                    profiles.etah = ones(60,1);
                    profiles.etau = ones(13,36,60);
                    if options.calc_vert_profiles
                        [rad,profiles] = RTMf(spectral,rad,soil,leafopt,canopy,gap,angles,profiles);
                    else
                        [rad] = RTMf(spectral,rad,soil,leafopt,canopy,gap,angles,profiles);
                    end
                end
        end
        if options.calc_fluor % total emitted fluorescence irradiance (excluding leaf and canopy re-absorption and scattering)
            if options.calc_PSI
                rad.Femtot = 1E3*(leafbio.fqe(2)* optipar.phiII(spectral.IwlF) * fluxes.aPAR_Cab_eta +leafbio.fqe(1)* optipar.phiI(spectral.IwlF)  * fluxes.aPAR_Cab);
            else
                rad.Femtot = 1E3*leafbio.fqe* optipar.phi(spectral.IwlF) * fluxes.aPAR_Cab_eta;
            end
        end   
        
        if options.store
            io.output_data(Output_dir, options, k, iter, xyt, fluxes, rad, thermal, gap, meteo, spectral, V, vi, vmax, profiles, directional, angles)
        end
    end
    
%%  Copmute reflectance factor
if options.calc_fluor
    SIF = zeros(length(IwlP),1);
    SIF(spectral.IwlF) = rad.LoF_; %% clf; plot(spectral.wlP,SIF)
else
    SIF = 0;
end

% % rad.Lo_ includes Xanthophylls' effect calculated by RTMz 
R = (rad.Lo_(IwlP).*pi + SIF)./(rad.Esky_ (IwlP) + rad.Esun_(IwlP));

end